import urllib.request
from selenium import webdriver
from getpass import getpass
from selenium.webdriver.support.ui import WebDriverWait
import xlrd

def key_finder(a):
        f = open("pass.txt","r")
        for line in f:
            if a in line:
                x=list(line)
                z=[]
                n=8
                for i in range(5):
                    z.append(x[n])
                    n=n+1
                    i=i+1
                    password = ''.join(z)
                i=i+1
        return password

def image_finder(x):
    url = ('http://intranet.rguktn.ac.in/SMS/usrphotos/user/'+x+'.jpg')
    full_path =  'images/'+ x +'.jpg'
    urllib.request.urlretrieve(url, full_path)

def image_downloader(x,y):
    url = ('http://intranet.rguktn.ac.in/SMS/usrphotos/user/'+x+'.jpg')
    full_path =  y
    urllib.request.urlretrieve(url, full_path)
        

def infoflyer (x,y):
    driver = webdriver.Chrome("Web driver//chromedriver.exe")
    driver.maximize_window()
    driver.get('http://intranet.rguktn.ac.in/SMS')
    driver.find_element_by_id('user1').send_keys(x)
    driver.find_element_by_id('passwd1').send_keys(y)
    driver.find_element_by_xpath("//button[@class='btn btn-primary']").click()
    driver.implicitly_wait(15)
    driver.find_element_by_xpath("//div[@class='box box-success box-solid']//div[1]//label[3]").click()
    driver.find_element_by_xpath("//body[@class='layout-top-nav skin-blue-light']//div[@class='row']//div[@class='row']//div[2]//label[2]").click()
    driver.find_element_by_xpath("//div[3]//label[3]").click()
    driver.find_element_by_xpath("//div[4]//label[4]").click()
    driver.find_element_by_xpath("//div[5]//label[3]").click()
    driver.find_element_by_xpath("//div[6]//label[2]").click()
    driver.find_element_by_xpath("//button[@id='mformsubmit']").click()
    driver.implicitly_wait(15)
    driver.find_element_by_xpath("//li[3]//a[1]//span[2]//i[1]").click()
    driver.find_element_by_xpath("//ul[@class='treeview-menu']//a[contains(text(),'Edit Profile')]").click()


