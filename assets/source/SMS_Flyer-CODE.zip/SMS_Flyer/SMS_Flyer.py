from tkinter import *
from tkinter.ttk import Progressbar
from PIL import ImageTk,Image
from logic import *
import pyperclip
from PIL import ImageTk,Image
import os
import urllib.request
import webbrowser
from tkinter.filedialog import asksaveasfile
from tkinter import messagebox
import time
import xlrd
from tkinter import filedialog

#window components

shell = Tk()
shell.title("SMS Flyer")
shell.iconbitmap("icons//icon.ico")
shell.geometry("330x515")
shell.minsize(330 , 515)
shell.maxsize(340,525)

#creator

creator=Label(shell,text="created by N170144",bd=1,fg="grey", relief=SUNKEN, anchor=E)

#components

lable1 = Label(shell, text="Enter Id number", font=("ArielBold",15), fg="blue" )

#image

file="icons//user.jpg"
image = Image.open(file)
img = ImageTk.PhotoImage(image.resize((250, 250)))
my_label = Label(shell, image=img)
my_label.image = img
my_label.grid(row=4,column=0,rowspan=3)

#functioning of buttons and error labels

def errorimg(x):
        global my_label
        if x==1:
                file="icons//nouser.jpg"
        else:
                file="icons//nonet.jpg"
        my_label.grid_forget()
        image = Image.open(file)
        img = ImageTk.PhotoImage(image.resize((250, 250)))
        my_label = Label(shell, image=img)
        my_label.image = img
        my_label.grid(row=4,column=0,rowspan=3)
        

def input1click():
        a=input1.get()
        error=0
        c="ID doesn't exist"
        try:
                b=key_finder(a)
        except IndexError:
                error=1
        except UnboundLocalError:
                error=1
        if error==0 and len(a)==7:
                input2.delete(0,END)
                input2.insert(0,b)
                
        else:
                input2.delete(0,END)
                input2.insert(0,c)
                messagebox.showwarning("ID Error","ID doesn't exist")
        if a=="N170144":
                creator=Label(shell,text="creator : Hey that's my ID number!!!",bd=1,fg="red", relief=SUNKEN, anchor=E)
                creator.grid(row=10, column=0,columnspan=3,sticky=W+E)
        else:
                creator=Label(shell,text="created by N170144",bd=1,fg="grey", relief=SUNKEN, anchor=E)
                creator.grid(row=10, column=0,columnspan=3,sticky=W+E)

def copy_to_clipboard():
    pyperclip.copy(input2.get())

def imagefinder():
        global my_label
        nonet=0
        noid=0
        a=input1.get()
        path="images//"
        if len(a)==7:
                try:
                        b=image_finder(a)
                except urllib.error.HTTPError as exception:
                        noid=1
                except urllib.error.URLError as exception:
                        nonet=1
                try:
                        file="images//"+a+".jpg"
                        my_label.grid_forget()
                        image = Image.open(file)
                        if image.size==(250,250):
                                img = ImageTk.PhotoImage(image.resize((250, 250)))
                        else:
                                img = ImageTk.PhotoImage(image.resize((210, 300))) 
                        my_label = Label(shell, image=img)
                        my_label.image = img
                        my_label.grid(row=4,column=0,rowspan=3)
                        
                except FileNotFoundError:
                        nofile=1
                if nonet==1:
                        errorimg(2)
                        messagebox.showinfo("Internet Error","Slow or no internet! check your internet settings")
                elif noid==1 and nofile==1:
                        errorimg(1)
                        messagebox.showwarning("ID Error","ID doesn't exist")
                        
                        
        else:
                errorimg(1)
                messagebox.showwarning("ID Error","ID doesn't exist")
        if a=="N170144" and nonet!=1:
                creator=Label(shell,text="creator : Hey that's me..",bd=1,fg="blue", relief=SUNKEN, anchor=E)
                creator.grid(row=10, column=0,columnspan=3,sticky=W+E)
        else:
                creator=Label(shell,text="created by N170144",bd=1,fg="grey", relief=SUNKEN, anchor=E)
                creator.grid(row=10, column=0,columnspan=3,sticky=W+E)

def imginfo():
        global my_label
        a=input1.get()
        httpe=0
        urle=0
        if len(a)==7:
                try:
                        b=image_finder(a)
                except urllib.error.HTTPError as exception:
                        httpe=1
                        errorimg(1)
                        messagebox.showwarning("ID Error","ID doesn't exist")
                except urllib.error.URLError as exception:
                        urle=1
                        errorimg(2)
                        messagebox.showinfo("Internet Error","Slow or no internet! check your internet settings")
                if len(a)==7 and httpe==0 and urle==0:
                        b=key_finder(a)
                        infoflyer(a,b)
        else:
                errorimg(1)
                messagebox.showwarning("ID Error","ID doesn't exist")
        
def save():
        x=input1.get()
        files = [('JPG Files', '*.jpg'),
        	('All Files', '*.*')]
        location = asksaveasfile(initialfile=x,filetypes = files, defaultextension = files,mode='a')
        y=location.name
        image_downloader(x,y)

               
def downloadwindow():
        top=Toplevel()
        top.geometry("325x210")
        top.minsize(325 , 210)
        top.maxsize(323,210)
        top.title("Download Flyer")
        top.iconbitmap("icons//icon.ico")
        lable1 = Label(top, text="Select year & Enter number", font=("ArielBold",15), fg="blue" )

        input1 = Entry(top,width=30)
        input1.insert(0,"0001")
        input2 = Entry(top,width=30)
        input2.insert(0,"0010")

        clicked = StringVar()
        clicked.set("Year")
        menu = OptionMenu(top, clicked, "N09","N10","N11","N12","N13","N14","N15","N16","N17","N18","N19")
        menu.config(width=5)

        def download_flyer(y,f,l,p):
                year=y
                file = "IDS.xls"
                workbook = xlrd.open_workbook(file)
                year_list=["N09","N10","N11","N12","N13","N14","N15","N16","N17","N18","N19"]
                index=year_list.index(y)
                sheet = workbook.sheet_by_index(0)
                t=int(l)-int(f)+1
                pgbr["maximum"]=t
                pgbr["value"]=0
                e=0
                for i in range(t):
                        time.sleep(0.05)
                        pgbr["value"]=i+1
                        x = sheet.cell_value(i,index)
                        url = ('http://intranet.rguktn.ac.in/SMS/usrphotos/user/'+x+'.jpg')
                        while True:
                                try:
                                        urllib.request.urlretrieve(url, p+"/"+x+".jpg")
                                        pgbr.update()
                                        break
                                except urllib.error.HTTPError as exception:
                                        e=1
                                        break
                                except urllib.error.URLError as exception:
                                        messagebox.showinfo("Internet Error","Slow or no internet! check your internet settings")
                                        e=2
                                        pgbr["value"]=0
                                        break
                                except PermissionError as exception:
                                        messagebox.showinfo("Location Error","No location found!")
                                        e=3
                                        pgbr["value"]=0
                                        break
                        if i+1==t:
                                messagebox.showinfo("Completed","Download Completed!")
                        elif e==2:
                                break
                        elif e==3:
                                break
                        i=i+1

        def loopdownload():
                
                y=clicked.get()
                f=int(input1.get())
                l=int(input2.get())
                t=int(l)-int(f)+1
                pgbr["maximum"]=t
                pgbr["value"]=0
                if len(y)!=3:
                        messagebox.showwarning("Year not choosen","Choose year and click select")
                elif f>=l:
                        messagebox.showwarning("Error","Invalid input")
                else:
                        folderPath = StringVar()
                        folder_selected = filedialog.askdirectory()
                        folderPath.set(folder_selected)
                        p = folderPath.get()
                        download_flyer(y,f,l,p)
        
        def year():
                lable2 = Label(top, text=clicked.get())
                lable4 = Label(top, text=clicked.get())
                lable2.grid(row=2,column=0)
                lable4.grid(row=4,column=0)
                
        lable2 = Label(top, text="Year",fg="Blue")
        lable3 = Label(top, text="TO",fg="Red")
        lable4 = Label(top, text="Year",fg="Blue")
        emptylable = Label(top)
        bt1 = Button(top,text="Select", bg="#b5eff7",padx=60,command=year)
        bt2 = Button(top,text="Download",padx=60,bg="#bef7b5",command=loopdownload)
        pgbr = Progressbar(top,length=200,orient=HORIZONTAL,mode='determinate')
        creator=Label(top,text="created by N170144",bd=1,fg="grey", relief=SUNKEN, anchor=E)

        lable1.grid(row=0,column=1,columnspan=1)
        menu.grid(row=1,column=0,columnspan=1)
        bt1.grid(row=1,column=1,columnspan=1)
        bt2.grid(row=5,column=1,columnspan=1)
        pgbr.grid(row=7,column=1,columnspan=1)
        emptylable.grid(row=6,column=1)
        lable2.grid(row=2,column=0)
        input1.grid(row=2,column=1)
        lable3.grid(row=3,column=1,columnspan=1)
        lable4.grid(row=4,column=0)
        input2.grid(row=4,column=1)
        creator.grid(row=10, column=0,columnspan=3,sticky=W+E)
        
#Entry tabs
        
input1 = Entry(shell,width=45)
input1.insert(0,"N17")

input2 = Entry(shell,width=45,bg="#b5eff7")
input2.insert(0,"passowrd")

#Buttons

bt1 = Button(shell,text="Find", padx=12,command=input1click)
bt2 = Button(shell,text="Copy", padx=10,command=copy_to_clipboard )
bt3 = Button(shell,text="Find Image", padx=90, border=3,bg="#e2b5f7", command=imagefinder)
bt4 = Button(shell,text="Info Flyer", padx=77, border=3, bg="#fcacc3", command=imginfo)
bt5 = Button(shell,text="Download Image", padx=70, border=3, bg="#bef7b5",command = lambda : save())
bt6 = Button(shell,text="Download Flyer", padx=90, border=3, bg="#f4f788",command = downloadwindow)

#Grid

lable1.grid(row=0,column=0)
input1.grid(row=1,column=0)
input2.grid(row=2,column=0)
bt1.grid(row=1,column=2)
bt2.grid(row=2,column=2)
bt3.grid(row=3,columnspan=2)
bt4.grid(row=7,columnspan=2)
bt5.grid(row=8,columnspan=2)
bt6.grid(row=9,columnspan=2)
creator.grid(row=10, column=0,columnspan=3,sticky=W+E)

shell.mainloop()

